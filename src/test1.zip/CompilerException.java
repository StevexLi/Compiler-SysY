public class CompilerException extends Exception{
    CompilerException(String str){
        super(str);
    }
}
