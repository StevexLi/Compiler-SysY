package Lexer;

import Lexer.LexType;

/**
 * 单词类
 *
 * @author Stevex
 * @date 2023/09/22
 */
public class Token {
    /**
     * 单词字符串
     */
    public String token;
    /**
     * 单词类型
     */
    public LexType type;
    /**
     * 单词所在行
     */
    public int line;
    /**
     * 单词数值（仅数值常量）
     */
    public int value;

    /**
     * 令 牌
     *
     * @param token 单词
     * @param type  单词类型
     * @param line  单词所在行
     */
    Token(String token, LexType type, int line) {
        this.token = token;
        this.type = type;
        this.line = line;
    }

    /**
     * 令 牌
     *
     * @param token 单词
     * @param type  单词类型
     * @param line  单词所在行
     * @param value 单词数值
     */
    Token(String token, LexType type, int line, int value) {
        this.token = token;
        this.type = type;
        this.line = line;
        this.value = value;
    }

    /**
     * 重写print方法
     *
     * @return {@link String}
     */
    @Override
    public String toString() {
        if (!type.lexEnumGetType().equals("INTCON")){
            return (token+' '+type+' '+line);
        }
        else {
            return (token+' '+type+' '+line+' '+value);
        }
    }
}
