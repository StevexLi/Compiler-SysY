import Lexer.*;
import Exception.*;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Compiler {
    static String source_code = "testfile.txt";
    static String lexer_output = "output.txt";
    static String source_code_string = "";
    static ArrayList<Token> token_list = new ArrayList<>();

    static void getSourceCodeString(String source_code) throws IOException {
        Path source_code_path = Paths.get(source_code);
        source_code_string = Files.readString(source_code_path);
    }

    static void writeTokenList() throws IOException {
        FileWriter writer;
        writer = new FileWriter(lexer_output);
        for (Token token:token_list){
            String str = token.type.lexEnumGetType()+' '+token.token;
            writer.write(str+'\n');
        }
        writer.flush();
        writer.close();
    }

    public static void main(String[] args) {
        try{
            getSourceCodeString(source_code);
            Lexer lexer = new Lexer(source_code_string,token_list);
            writeTokenList();
        } catch (CompilerException e){
            System.out.println("Exception.CompilerException:"+e.getMessage());
        } catch (IOException e) {
            System.out.println("IOException:"+e.getMessage());
        } catch (Exception e) {
            System.out.println("Exception:"+e.getMessage());
        }
    }
}
