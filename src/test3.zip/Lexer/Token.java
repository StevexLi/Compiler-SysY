package Lexer;

import Lexer.LexType;

public class Token {
    public String token;
    public LexType type;
    public int line;
    public int value;

    Token(String token, LexType type, int line) {
        this.token = token;
        this.type = type;
        this.line = line;
    }

    Token(String token, LexType type, int line, int value) {
        this.token = token;
        this.type = type;
        this.line = line;
        this.value = value;
    }

    @Override
    public String toString() {
        if (!type.lexEnumGetType().equals("INTCON")){
            return (token+' '+type+' '+line);
        }
        else {
            return (token+' '+type+' '+line+' '+value);
        }
    }
}
