package Lexer;

import Exception.*;

import java.util.HashMap;

public enum LexType {
    IDENFR("Ident","IDENFR"),
    INTCON("IntConst","INTCON"),
    STRCON("FormatString", "STRCON"),
    MAINTK("main", "MAINTK"),
    CONSTTK("const", "CONSTTK"),
    INTTK("int", "INTTK"),
    BREAKTK("break", "BREAKTK"),
    CONTINUETK("continue", "CONTINUETK"),
    IFTK("if", "IFTK"),
    ELSETK("else", "ELSETK"),
    NOT("!", "NOT"),
    AND("&&", "AND"),
    OR("||", "OR"),
    FORTK("for", "FORTK"),
    GETINTTK("getint", "GETINTTK"),
    PRINTFTK("printf", "PRINTFTK"),
    RETURNTK("return", "RETURNTK"),
    PLUS("+", "PLUS"),
    MINU("-", "MINU"),
    VOIDTK("void", "VOIDTK"),
    MULT("*", "MULT"),
    DIV("/", "DIV"),
    MOD("%", "MOD"),
    LSS("<", "LSS"),
    LEQ("<=", "LEQ"),
    GRE(">", "GRE"),
    GEQ(">=", "GEQ"),
    EQL("==", "EQL"),
    NEQ("!=", "NEQ"),
    ASSIGN("=", "ASSIGN"),
    SEMICN(";", "SEMICN"),
    COMMA(",", "COMMA"),
    LPARENT("(", "LPARENT"),
    RPARENT(")", "RPARENT"),
    LBRACK("[", "LBRACK"),
    RBRACK("]", "RBRACK"),
    LBRACE("{", "LBRACE"),
    RBRACE("}", "RBRACE"),
    ;

    private String word;
    private String type;

    LexType(String word, String type) {
        this.word = word;
        this.type = type;
    }

    public String lexEnumGetWord() {
        return word;
    }

    public String lexEnumGetType() {
        return type;
    }

    static void buildReserveWordsMap(HashMap<String, LexType> reserveWords) {
        LexType[] lexTypes = LexType.values();
        for (LexType lexType : lexTypes) {
            if(lexType.lexEnumGetType().matches(".*TK$")){
                reserveWords.put(lexType.lexEnumGetWord(),lexType);
            }
        }
    }

    public static String lexEnumGetTypeByWord(String word) throws CompilerException {
        String type = "!NONE!";
        LexType[] lexTypes = LexType.values();
        for (LexType lexType : lexTypes) {
            if(lexType.lexEnumGetWord().equals(word)){
                type =  lexType.lexEnumGetType();
                break;
            }
        }
        if (type.equals("!NONE!")){
            throw new CompilerException("invalid word");
        }
        return type;
    }

    public static String lexEnumGetWordByType(String type) throws CompilerException {
        String word = "!NONE!";
        LexType[] lexTypes = LexType.values();
        for (LexType lexType : lexTypes) {
            if(lexType.lexEnumGetType().equals(type)){
                word = lexType.lexEnumGetWord();
                break;
            }
        }
        if (word.equals("!NONE!")){
            throw new CompilerException("invalid type");
        }
        return word;
    }
}
