package Exception;

public class CompilerException extends Exception{
    public CompilerException(String str){
        super(str);
    }
}
